package sign;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.sql.ResultSet;
import javax.swing.JOptionPane;

public class signup1 extends javax.swing.JFrame {
   
    public signup1() {
        initComponents();
        btngomenu1.setEnabled(false);
        textwallet.setEditable(false);
       
        try{
        Class.forName("org.apache.derby.jdbc.ClientDriver");  
        Connection con=DriverManager.getConnection( "jdbc:derby://localhost:1527/store", "mansipalak", "mansipalak" );
        Statement stmt=con.createStatement();
        ResultSet rs = stmt.executeQuery("SELECT * FROM MANSIPALAK.signup1");
        }
        catch(Exception e){
            System.out.println(e);  
    }
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        labelSap = new javax.swing.JLabel();
        textSap = new javax.swing.JTextField();
        labelPass = new javax.swing.JLabel();
        btnLogin = new javax.swing.JButton();
        textPass = new javax.swing.JPasswordField();
        btnprev = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        textwallet = new javax.swing.JTextField();
        btngomenu1 = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(null);

        labelSap.setFont(new java.awt.Font("Tahoma", 3, 20)); // NOI18N
        labelSap.setForeground(new java.awt.Color(255, 255, 255));
        labelSap.setText("SAP-ID:");
        getContentPane().add(labelSap);
        labelSap.setBounds(150, 230, 90, 30);

        textSap.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        getContentPane().add(textSap);
        textSap.setBounds(250, 230, 160, 30);

        labelPass.setFont(new java.awt.Font("Tahoma", 3, 20)); // NOI18N
        labelPass.setForeground(new java.awt.Color(255, 255, 255));
        labelPass.setText("PASSWORD:");
        getContentPane().add(labelPass);
        labelPass.setBounds(100, 290, 150, 30);

        btnLogin.setFont(new java.awt.Font("Tahoma", 3, 18)); // NOI18N
        btnLogin.setText("LOG IN");
        btnLogin.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLoginActionPerformed(evt);
            }
        });
        getContentPane().add(btnLogin);
        btnLogin.setBounds(270, 410, 130, 40);
        getContentPane().add(textPass);
        textPass.setBounds(250, 290, 160, 30);

        btnprev.setFont(new java.awt.Font("Tahoma", 3, 14)); // NOI18N
        btnprev.setText("PREVIOUS PAGE");
        btnprev.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnprevActionPerformed(evt);
            }
        });
        getContentPane().add(btnprev);
        btnprev.setBounds(40, 535, 150, 40);

        jLabel1.setFont(new java.awt.Font("Tahoma", 3, 20)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("WALLET BALANCE:");
        getContentPane().add(jLabel1);
        jLabel1.setBounds(40, 350, 200, 30);

        textwallet.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        getContentPane().add(textwallet);
        textwallet.setBounds(250, 350, 160, 30);

        btngomenu1.setFont(new java.awt.Font("Tahoma", 3, 14)); // NOI18N
        btngomenu1.setText("GO TO MENU");
        btngomenu1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btngomenu1ActionPerformed(evt);
            }
        });
        getContentPane().add(btngomenu1);
        btngomenu1.setBounds(740, 540, 160, 40);

        jLabel2.setFont(new java.awt.Font("Tahoma", 3, 36)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("LOGIN PAGE");
        getContentPane().add(jLabel2);
        jLabel2.setBounds(150, 90, 240, 50);

        jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/sign/f7.jpeg"))); // NOI18N
        getContentPane().add(jLabel4);
        jLabel4.setBounds(0, 0, 940, 620);

        setSize(new java.awt.Dimension(947, 655));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents
    
 
    private void btnLoginActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLoginActionPerformed
 
        int f=1;
        try{ 
        Class.forName("org.apache.derby.jdbc.ClientDriver");        
        }
        catch(ClassNotFoundException e){
            System.out.println(e);
        }
        try{
        Connection con=DriverManager.getConnection( "jdbc:derby://localhost:1527/store", "mansipalak", "mansipalak" );
        Statement stmt=con.createStatement();
        ResultSet rs = stmt.executeQuery("SELECT * FROM MANSIPALAK.signup1");
        
        String sap=textSap.getText();
        String pass=textPass.getText();
        
        while(rs.next())
        {
        int numsap = rs.getInt("SAP_ID");
        String s = Integer.toString(numsap);
        String p = rs.getString("PASSWORD");
        int wall= rs.getInt("WALLET");
        String w = Integer.toString(wall);
        
        if(s.equals(sap) && p.equals(pass))
        {
            f=0;
            textwallet.setText(w);
            String print = textwallet.getText();
            btngomenu1.setEnabled(true);
            JOptionPane.showMessageDialog(null, "Login Successful.\nYour Wallet Balance is Rs " +print+ "\nProceed to order.");  
            break;
        } 
        }
        if (f==1)
       {
           JOptionPane.showMessageDialog(null, "INVALID Username or Password or Account doesn't exist");
       } }
        
           catch(Exception e){
            System.out.println(e);  
          }
  
        
    }//GEN-LAST:event_btnLoginActionPerformed

    private void btnprevActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnprevActionPerformed
       new welcome().setVisible(true);
    }//GEN-LAST:event_btnprevActionPerformed

    private void btngomenu1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btngomenu1ActionPerformed
      String msg = textwallet.getText();
      String msg1 = textSap.getText();
        new Menu(msg,msg1).setVisible(true); 
    }//GEN-LAST:event_btngomenu1ActionPerformed

    public static void main(String args[]) {
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(signup1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        java.awt.EventQueue.invokeLater(() -> {
            new signup1().setVisible(true);
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnLogin;
    private javax.swing.JButton btngomenu1;
    private javax.swing.JButton btnprev;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel labelPass;
    private javax.swing.JLabel labelSap;
    private javax.swing.JPasswordField textPass;
    private javax.swing.JTextField textSap;
    private javax.swing.JTextField textwallet;
    // End of variables declaration//GEN-END:variables
}
