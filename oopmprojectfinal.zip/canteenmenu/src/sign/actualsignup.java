package sign;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;

public class actualsignup extends javax.swing.JFrame {
 
    public actualsignup() {
        initComponents();
        btngomenu.setEnabled(false);
    }
      
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        labelnewsap = new javax.swing.JLabel();
        textnewsap = new javax.swing.JTextField();
        textnewpass = new javax.swing.JPasswordField();
        textnewwallet = new javax.swing.JTextField();
        btnnewcreate = new javax.swing.JButton();
        labelnewpass = new javax.swing.JLabel();
        btnprev = new javax.swing.JButton();
        btngomenu = new javax.swing.JButton();
        labelnewwallet = new javax.swing.JLabel();
        btngologin = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(null);

        labelnewsap.setFont(new java.awt.Font("Tahoma", 3, 18)); // NOI18N
        labelnewsap.setText("NEW SAP-ID :");
        getContentPane().add(labelnewsap);
        labelnewsap.setBounds(60, 142, 140, 30);

        textnewsap.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                textnewsapActionPerformed(evt);
            }
        });
        getContentPane().add(textnewsap);
        textnewsap.setBounds(210, 140, 130, 30);

        textnewpass.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                textnewpassActionPerformed(evt);
            }
        });
        getContentPane().add(textnewpass);
        textnewpass.setBounds(210, 190, 130, 30);

        textnewwallet.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                textnewwalletActionPerformed(evt);
            }
        });
        getContentPane().add(textnewwallet);
        textnewwallet.setBounds(210, 240, 130, 30);

        btnnewcreate.setFont(new java.awt.Font("Tahoma", 3, 14)); // NOI18N
        btnnewcreate.setText("CREATE");
        btnnewcreate.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnnewcreateActionPerformed(evt);
            }
        });
        getContentPane().add(btnnewcreate);
        btnnewcreate.setBounds(40, 320, 130, 40);

        labelnewpass.setFont(new java.awt.Font("Tahoma", 3, 18)); // NOI18N
        labelnewpass.setText("NEW PASSWORD :");
        getContentPane().add(labelnewpass);
        labelnewpass.setBounds(30, 190, 170, 22);

        btnprev.setFont(new java.awt.Font("Tahoma", 3, 13)); // NOI18N
        btnprev.setText("Previous Page");
        btnprev.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnprevActionPerformed(evt);
            }
        });
        getContentPane().add(btnprev);
        btnprev.setBounds(10, 560, 140, 40);

        btngomenu.setFont(new java.awt.Font("Tahoma", 3, 14)); // NOI18N
        btngomenu.setText("GO TO MENU");
        btngomenu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btngomenuActionPerformed(evt);
            }
        });
        getContentPane().add(btngomenu);
        btngomenu.setBounds(200, 320, 150, 40);

        labelnewwallet.setFont(new java.awt.Font("Tahoma", 3, 18)); // NOI18N
        labelnewwallet.setText("ADD TO WALLET:");
        getContentPane().add(labelnewwallet);
        labelnewwallet.setBounds(40, 240, 170, 22);

        btngologin.setFont(new java.awt.Font("Tahoma", 3, 14)); // NOI18N
        btngologin.setText("Already have an account ? Click to LOGIN");
        btngologin.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btngologinActionPerformed(evt);
            }
        });
        getContentPane().add(btngologin);
        btngologin.setBounds(40, 390, 320, 50);

        jLabel1.setFont(new java.awt.Font("Tahoma", 3, 24)); // NOI18N
        jLabel1.setText("SIGN-UP PAGE");
        getContentPane().add(jLabel1);
        jLabel1.setBounds(110, 40, 210, 50);

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/sign/f9.jpeg"))); // NOI18N
        getContentPane().add(jLabel2);
        jLabel2.setBounds(0, -20, 930, 660);

        setSize(new java.awt.Dimension(948, 661));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void btnprevActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnprevActionPerformed
        new welcome().setVisible(true);
    }//GEN-LAST:event_btnprevActionPerformed

    private void btngomenuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btngomenuActionPerformed
        String msg2= textnewwallet.getText();
        String msg3 = textnewsap.getText();
        new Menu(msg2,msg3).setVisible(true);
    }//GEN-LAST:event_btngomenuActionPerformed
          
    private void btnnewcreateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnnewcreateActionPerformed

        btngologin.setEnabled(false);
        if(textnewsap.getText().isEmpty() || textnewpass.getText().isEmpty() || textnewwallet.getText().isEmpty() )
     {
       JOptionPane.showMessageDialog(null, "Please Enter Valid Details");
     }
     else
     {
      try{ 
        Class.forName("org.apache.derby.jdbc.ClientDriver");        
        }
        catch(ClassNotFoundException e){
            System.out.println(e);
        }
      
        int c=1;
        try{
           
        Connection con=DriverManager.getConnection( "jdbc:derby://localhost:1527/store", "mansipalak", "mansipalak" );
        Statement stmt=con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_UPDATABLE);
        ResultSet rs = stmt.executeQuery("SELECT * FROM MANSIPALAK.signup1");
    
        String newsap = textnewsap.getText();
        int newsap1=Integer.parseInt(newsap);
        String newpass= textnewpass.getText();
        String newwallet=textnewwallet.getText();
        int newwallet1=Integer.parseInt(newwallet);
       
       while(rs.next())
        {
        int numsap = rs.getInt("SAP_ID");
        String s = Integer.toString(numsap);
        String p = rs.getString("PASSWORD");
        
       if( s.equals(textnewsap.getText()))
                {
                 c=0;
                 JOptionPane.showMessageDialog(null, "Account already exists. Proceed to Login");
                }
        }
         
      if(c==1)
          {
           btngomenu.setEnabled(true);
           JOptionPane.showMessageDialog(null, "Account created successfully.Proceed to Order ");
          }
      
        try{
          int curRow = rs.getRow();
           rs.moveToInsertRow();
      
            rs.updateInt("SAP_ID", newsap1);
            rs.updateString("PASSWORD", newpass);
            rs.updateInt("WALLET", newwallet1);
            
            rs.insertRow();
            rs.moveToCurrentRow();
            
            stmt.close();
            rs.close();

        }
        catch(SQLException err){
           System.out.print(err.getMessage());
        }
        }
         catch(SQLException err){
        JOptionPane.showMessageDialog(actualsignup.this,err.getMessage());
    }} 
    }//GEN-LAST:event_btnnewcreateActionPerformed
    
    private void textnewpassActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_textnewpassActionPerformed

    }//GEN-LAST:event_textnewpassActionPerformed


    private void textnewsapActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_textnewsapActionPerformed
  
    }//GEN-LAST:event_textnewsapActionPerformed

   
    
    private void btngologinActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btngologinActionPerformed
        new signup1().setVisible(true);
    }//GEN-LAST:event_btngologinActionPerformed

    private void textnewwalletActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_textnewwalletActionPerformed
       
    }//GEN-LAST:event_textnewwalletActionPerformed

    
    public static void main(String args[]) {
       
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new actualsignup().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btngologin;
    private javax.swing.JButton btngomenu;
    private javax.swing.JButton btnnewcreate;
    private javax.swing.JButton btnprev;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel labelnewpass;
    private javax.swing.JLabel labelnewsap;
    private javax.swing.JLabel labelnewwallet;
    private javax.swing.JPasswordField textnewpass;
    private javax.swing.JTextField textnewsap;
    private javax.swing.JTextField textnewwallet;
    // End of variables declaration//GEN-END:variables


}
