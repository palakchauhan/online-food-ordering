package sign;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Menu extends javax.swing.JFrame {
    
    private double walletbalance = 0;
    
    public Menu(String p, String q) {
        initComponents();
        btntotal.setEnabled(false);
        textbill.setEditable(false);
        textwallet1.setEditable(false);
        btnconfirm.setEnabled(false);
        textwallet1.setText(p);
        walletbalance = Double.parseDouble(p);
       textsapidcheck.setEditable(false);
       textsapidcheck.setText(q);
    }

    public Menu()
    {
     initComponents();
     try{
        Class.forName("org.apache.derby.jdbc.ClientDriver");  
        Connection con=DriverManager.getConnection( "jdbc:derby://localhost:1527/store", "mansipalak", "mansipalak" );
        Statement stmt=con.createStatement();
        ResultSet rs = stmt.executeQuery("SELECT * FROM MANSIPALAK.signup1");
        }
        catch(Exception e){
            System.out.println(e);  
        }
     
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        labelcanteen = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        textbill = new javax.swing.JTextField();
        textwallet1 = new javax.swing.JTextField();
        labelbalance = new javax.swing.JLabel();
        labelbill = new javax.swing.JLabel();
        btnreset = new javax.swing.JButton();
        btnconfirm = new javax.swing.JButton();
        btntotal = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        btnexit = new javax.swing.JButton();
        jLabel9 = new javax.swing.JLabel();
        btndosa = new javax.swing.JCheckBox();
        btnjuice = new javax.swing.JCheckBox();
        btnnoodles = new javax.swing.JCheckBox();
        btnpani = new javax.swing.JCheckBox();
        btnidli = new javax.swing.JCheckBox();
        btnvada = new javax.swing.JCheckBox();
        jLabel8 = new javax.swing.JLabel();
        btnsalad = new javax.swing.JCheckBox();
        btnsandwich = new javax.swing.JCheckBox();
        jLabel3 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        textsapidcheck = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(255, 153, 153));
        getContentPane().setLayout(null);

        jPanel1.setBackground(new java.awt.Color(153, 204, 255));

        labelcanteen.setBackground(new java.awt.Color(0, 0, 0));
        labelcanteen.setFont(new java.awt.Font("Corbel", 3, 40)); // NOI18N
        labelcanteen.setText("CANTEEN MENU");

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        jLabel2.setText("DOSA - Rs 50");

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        jLabel1.setText("IDLI-Rs 30");

        jPanel2.setBackground(new java.awt.Color(153, 204, 255));

        textbill.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        textbill.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        textbill.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                textbillActionPerformed(evt);
            }
        });

        textwallet1.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        textwallet1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        textwallet1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                textwallet1ActionPerformed(evt);
            }
        });

        labelbalance.setFont(new java.awt.Font("Tahoma", 3, 16)); // NOI18N
        labelbalance.setText("WALLET BALANCE:");

        labelbill.setBackground(new java.awt.Color(0, 0, 0));
        labelbill.setFont(new java.awt.Font("Tahoma", 3, 16)); // NOI18N
        labelbill.setText("BILL AMOUNT:");

        btnreset.setFont(new java.awt.Font("Tahoma", 3, 14)); // NOI18N
        btnreset.setText("RESET ORDER");
        btnreset.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnresetActionPerformed(evt);
            }
        });

        btnconfirm.setFont(new java.awt.Font("Tahoma", 3, 14)); // NOI18N
        btnconfirm.setText("CONFIRM ORDER");
        btnconfirm.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnconfirmActionPerformed(evt);
            }
        });

        btntotal.setFont(new java.awt.Font("Tahoma", 3, 14)); // NOI18N
        btntotal.setText("CALCULATE TOTAL");
        btntotal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btntotalActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addGap(43, 43, 43)
                .addComponent(btnreset, javax.swing.GroupLayout.PREFERRED_SIZE, 147, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 130, Short.MAX_VALUE)
                .addComponent(btntotal)
                .addGap(103, 103, 103)
                .addComponent(btnconfirm, javax.swing.GroupLayout.PREFERRED_SIZE, 172, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(labelbalance)
                    .addComponent(labelbill))
                .addGap(37, 37, 37)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(textbill, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 132, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(textwallet1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 132, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(194, 194, 194))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(labelbill)
                    .addComponent(textbill, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(13, 13, 13)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(labelbalance)
                    .addComponent(textwallet1, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(24, 24, 24)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnconfirm, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btntotal, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnreset, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(22, Short.MAX_VALUE))
        );

        jLabel4.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        jLabel4.setText("NOODLES Rs 45");

        jLabel5.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        jLabel5.setText("SANDWICH Rs 55");

        jLabel6.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        jLabel6.setText("SALAD BOWL Rs 30");

        jLabel7.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        jLabel7.setText("JUICE Rs 50");

        btnexit.setFont(new java.awt.Font("Tahoma", 3, 12)); // NOI18N
        btnexit.setText("EXIT");
        btnexit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnexitActionPerformed(evt);
            }
        });

        jLabel9.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel9.setText("( Click to Select. Double click to Deselect )");

        btndosa.setBackground(new java.awt.Color(255, 255, 255));
        btndosa.setIcon(new javax.swing.ImageIcon(getClass().getResource("/sign/rsz_1rsz_1rsz_dosanew.jpg"))); // NOI18N
        btndosa.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btndosaActionPerformed(evt);
            }
        });

        btnjuice.setBackground(new java.awt.Color(255, 255, 255));
        btnjuice.setIcon(new javax.swing.ImageIcon(getClass().getResource("/sign/rsz_1rsz_1rsz_1rsz_2rsz_1rsz_1juiceee.jpg"))); // NOI18N
        btnjuice.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnjuiceActionPerformed(evt);
            }
        });

        btnnoodles.setBackground(new java.awt.Color(255, 255, 255));
        btnnoodles.setIcon(new javax.swing.ImageIcon(getClass().getResource("/sign/rsz_1rsz_1rsz_1rsz_1noods.jpg"))); // NOI18N
        btnnoodles.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnnoodlesActionPerformed(evt);
            }
        });

        btnpani.setBackground(new java.awt.Color(255, 255, 255));
        btnpani.setIcon(new javax.swing.ImageIcon(getClass().getResource("/sign/rsz_1rsz_1rsz_paniiipurii.jpg"))); // NOI18N
        btnpani.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnpaniActionPerformed(evt);
            }
        });

        btnidli.setBackground(new java.awt.Color(255, 255, 255));
        btnidli.setIcon(new javax.swing.ImageIcon(getClass().getResource("/sign/rsz_21rsz_idddli.jpg"))); // NOI18N
        btnidli.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnidliActionPerformed(evt);
            }
        });

        btnvada.setBackground(new java.awt.Color(255, 255, 255));
        btnvada.setIcon(new javax.swing.ImageIcon(getClass().getResource("/sign/rsz_1download_2.jpeg"))); // NOI18N
        btnvada.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnvadaActionPerformed(evt);
            }
        });

        jLabel8.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        jLabel8.setText("PANI PURI Rs 40");

        btnsalad.setIcon(new javax.swing.ImageIcon(getClass().getResource("/sign/rsz_salaaad.jpg"))); // NOI18N
        btnsalad.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnsaladActionPerformed(evt);
            }
        });

        btnsandwich.setBackground(new java.awt.Color(255, 255, 255));
        btnsandwich.setIcon(new javax.swing.ImageIcon(getClass().getResource("/sign/rsz_1sanddddd.jpg"))); // NOI18N
        btnsandwich.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnsandwichActionPerformed(evt);
            }
        });

        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        jLabel3.setText("VADA PAV-Rs 15");

        jLabel10.setFont(new java.awt.Font("Tahoma", 3, 13)); // NOI18N
        jLabel10.setText("SAP ID:");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(109, 109, 109)
                        .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 97, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(85, 85, 85)
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(104, 104, 104)
                        .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(101, 101, 101)
                        .addComponent(jLabel4))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(70, 70, 70)
                        .addComponent(btnvada)
                        .addGap(27, 27, 27)
                        .addComponent(btnsandwich)
                        .addGap(38, 38, 38)
                        .addComponent(btnsalad)
                        .addGap(35, 35, 35)
                        .addComponent(btnpani))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(24, 24, 24)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 126, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(52, 52, 52)
                                .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 133, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(64, 64, 64)
                                .addComponent(jLabel6)
                                .addGap(89, 89, 89)
                                .addComponent(jLabel8))))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addGroup(jPanel1Layout.createSequentialGroup()
                                    .addGap(121, 121, 121)
                                    .addComponent(labelcanteen, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                .addGroup(jPanel1Layout.createSequentialGroup()
                                    .addGap(70, 70, 70)
                                    .addComponent(btnjuice)
                                    .addGap(27, 27, 27)
                                    .addComponent(btnidli)))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addContainerGap()
                                .addComponent(jLabel10)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(textsapidcheck, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(38, 38, 38)
                                .addComponent(btndosa, javax.swing.GroupLayout.PREFERRED_SIZE, 165, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(35, 35, 35)
                                .addComponent(btnnoodles))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 308, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(btnexit, javax.swing.GroupLayout.PREFERRED_SIZE, 72, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addContainerGap(36, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel10)
                            .addComponent(textsapidcheck, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel9)
                            .addComponent(labelcanteen)))
                    .addComponent(btnexit, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(15, 15, 15)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnjuice, javax.swing.GroupLayout.PREFERRED_SIZE, 116, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnidli)
                    .addComponent(btndosa, javax.swing.GroupLayout.PREFERRED_SIZE, 118, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnnoodles, javax.swing.GroupLayout.PREFERRED_SIZE, 118, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(3, 3, 3)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel7)
                    .addComponent(jLabel1)
                    .addComponent(jLabel2)
                    .addComponent(jLabel4))
                .addGap(9, 9, 9)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnvada, javax.swing.GroupLayout.PREFERRED_SIZE, 117, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnsandwich)
                    .addComponent(btnsalad, javax.swing.GroupLayout.PREFERRED_SIZE, 117, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnpani))
                .addGap(3, 3, 3)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel3)
                    .addComponent(jLabel5)
                    .addComponent(jLabel6)
                    .addComponent(jLabel8))
                .addGap(18, 18, 18)
                .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        getContentPane().add(jPanel1);
        jPanel1.setBounds(0, 0, 860, 600);

        setSize(new java.awt.Dimension(870, 647));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents
  

    private void btnexitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnexitActionPerformed
        System.exit(0);
    }//GEN-LAST:event_btnexitActionPerformed

    private void btnresetActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnresetActionPerformed
      btnidli.setSelected(false);
       btndosa.setSelected(false);
        btnpani.setSelected(false);
         btnsandwich.setSelected(false);
          btnsalad.setSelected(false);
           btnjuice.setSelected(false);
            btnvada.setSelected(false);
             btnnoodles.setSelected(false);
        
        textbill.setText("");
       textwallet1.setText("");
       if(textbill.getText().equals("")&& textwallet1.getText().equals("") ){
           textbill.setText("0");
           textwallet1.setText(""+walletbalance);
       }
    }//GEN-LAST:event_btnresetActionPerformed

    
    
    private void btntotalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btntotalActionPerformed
       btnjuice.setEnabled(true);
       btnidli.setEnabled(true);
       btndosa.setEnabled(true);
       btnsandwich.setEnabled(true);
       btnsalad.setEnabled(true);
       btnpani.setEnabled(true);
       btnvada.setEnabled(true);
       btnnoodles.setEnabled(true);
       
       
        
        btnconfirm.setEnabled(true);
        double total=0;
        double w = Double.parseDouble(textwallet1.getText());
     
        if (btndosa.isSelected()){
            total= total +50.0;
           
        }
        
        if (btnidli.isSelected()){
            total= total +30.0;
        }
        
        if (btnjuice.isSelected()){
            total= total +50.0;
        }
        
        if (btnsandwich.isSelected()){
            total= total +55.0;
        }
       
        if (btnnoodles.isSelected()){
            total= total +45.0;
        }
       
        if (btnpani.isSelected()){
            total= total +40.0;
        }
       
        if (btnvada.isSelected()){
            total= total +15.0;
        }
       
        if (btnsalad.isSelected()){
            total= total +30.0;    
       }
       
      textbill.setText(Double.toString(total));
      int w1 = (int)walletbalance;
      int w2 = w1-(int)total; 
      textwallet1.setText(Integer.toString(w2)); 
    }//GEN-LAST:event_btntotalActionPerformed
  
    
     public void update() throws SQLException{
        try{
        Class.forName("org.apache.derby.jdbc.ClientDriver");  
        Connection con=DriverManager.getConnection( "jdbc:derby://localhost:1527/store", "mansipalak", "mansipalak" );
        String SQL="UPDATE SIGNUP1 SET WALLET=? WHERE SAP_ID=?";
        PreparedStatement pstmt=con.prepareStatement(SQL);
        pstmt.setString(1,textwallet1.getText());
        pstmt.setString(2,textsapidcheck.getText());
        
        
            int executeUpdate = pstmt.executeUpdate();
 
               
        }
        catch(ClassNotFoundException | NumberFormatException | SQLException e){
            System.out.println(e);  
    }
    }
    
       
    private void btnconfirmActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnconfirmActionPerformed
        try {
            update();
        } catch (SQLException ex) {
            Logger.getLogger(Menu.class.getName()).log(Level.SEVERE, null, ex);
        }
     String uw=textwallet1.getText();
     int u =Integer.parseInt(uw);
      String tot = textbill.getText();
      int uw1=Integer.parseInt(uw);
        if( uw1 < 0)
        { 
            uw1 = Math.abs(uw1);
            u=0;
            uw=Integer.toString(u);
        }
        else
        {
        uw1=0;
        }
        String uw2=Integer.toString(uw1);
      new thankyou(uw,uw2,tot).setVisible(true);
      
      /*
        int uw1=Integer.parseInt(uw);
        if( uw1 < 0)
        { 
            uw1 = Math.abs(uw1);
            JOptionPane.showMessageDialog(null, "THANK YOU FOR ORDERING \n Your Bill Amount is Rs " +tot+ "\n Amount to be paid is Rs " +uw1+ "\nWallet Balance is Rs 0 ");                               
        } 
        else 
        {
            JOptionPane.showMessageDialog(null, "THANK YOU FOR ORDERING \n Your Bill Amount is Rs " +tot+ "\nWallet Balance is Rs " +uw1);  
    }//GEN-LAST:event_btnconfirmActionPerformed
  */
    }
    private void textwallet1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_textwallet1ActionPerformed

    }//GEN-LAST:event_textwallet1ActionPerformed

    private void textbillActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_textbillActionPerformed

    }//GEN-LAST:event_textbillActionPerformed

    private void btndosaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btndosaActionPerformed
        btntotal.setEnabled(true);
       btndosa.setEnabled(false);
    }//GEN-LAST:event_btndosaActionPerformed

    private void btnvadaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnvadaActionPerformed
    btntotal.setEnabled(true);
      btnvada.setEnabled(false);
    }//GEN-LAST:event_btnvadaActionPerformed

    private void btnsandwichActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnsandwichActionPerformed
       btntotal.setEnabled(true);
         btnsandwich.setEnabled(false);
    }//GEN-LAST:event_btnsandwichActionPerformed

    private void btnidliActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnidliActionPerformed
       btntotal.setEnabled(true);
         btnidli.setEnabled(false);
    }//GEN-LAST:event_btnidliActionPerformed

    private void btnjuiceActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnjuiceActionPerformed
    btntotal.setEnabled(true);
    btnjuice.setEnabled(false);
    }//GEN-LAST:event_btnjuiceActionPerformed

    private void btnnoodlesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnnoodlesActionPerformed
        btntotal.setEnabled(true);
         btnnoodles.setEnabled(false);
    }//GEN-LAST:event_btnnoodlesActionPerformed

    private void btnsaladActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnsaladActionPerformed
      btntotal.setEnabled(true);
        btnsalad.setEnabled(false);
    }//GEN-LAST:event_btnsaladActionPerformed

    private void btnpaniActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnpaniActionPerformed
       btntotal.setEnabled(true);
         btnpani.setEnabled(false);
    }//GEN-LAST:event_btnpaniActionPerformed

    public static void main(String args[]) {
      
        java.awt.EventQueue.invokeLater(() -> {
            new Menu().setVisible(true);
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnconfirm;
    private javax.swing.JCheckBox btndosa;
    private javax.swing.JButton btnexit;
    private javax.swing.JCheckBox btnidli;
    private javax.swing.JCheckBox btnjuice;
    private javax.swing.JCheckBox btnnoodles;
    private javax.swing.JCheckBox btnpani;
    private javax.swing.JButton btnreset;
    private javax.swing.JCheckBox btnsalad;
    private javax.swing.JCheckBox btnsandwich;
    private javax.swing.JButton btntotal;
    private javax.swing.JCheckBox btnvada;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JLabel labelbalance;
    private javax.swing.JLabel labelbill;
    private javax.swing.JLabel labelcanteen;
    private javax.swing.JTextField textbill;
    private javax.swing.JTextField textsapidcheck;
    private javax.swing.JTextField textwallet1;
    // End of variables declaration//GEN-END:variables
}