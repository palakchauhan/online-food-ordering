
package sign;
public class thankyou extends javax.swing.JFrame {

   
    public thankyou(String a, String b, String c) {
        initComponents();
        billp.setEditable(false);
        wallp.setEditable(false);
        paidp.setEditable(false);
        billp.setText(c);
        paidp.setText(b);
        wallp.setText(a);
        
    }

 
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        bill = new javax.swing.JLabel();
        wall = new javax.swing.JLabel();
        paid = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        billp = new javax.swing.JTextField();
        paidp = new javax.swing.JTextField();
        wallp = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        IMAGE = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setSize(new java.awt.Dimension(900, 600));
        getContentPane().setLayout(null);

        bill.setFont(new java.awt.Font("Tahoma", 3, 18)); // NOI18N
        bill.setForeground(new java.awt.Color(255, 255, 255));
        bill.setText(" BILL AMOUNT IS  Rs    ");
        getContentPane().add(bill);
        bill.setBounds(580, 450, 210, 30);

        wall.setFont(new java.awt.Font("Tahoma", 3, 18)); // NOI18N
        wall.setForeground(new java.awt.Color(255, 255, 255));
        wall.setText("WALLET BALANCE IS  Rs");
        getContentPane().add(wall);
        wall.setBounds(550, 530, 220, 30);

        paid.setFont(new java.awt.Font("Tahoma", 3, 18)); // NOI18N
        paid.setForeground(new java.awt.Color(255, 255, 255));
        paid.setText("AMOUNT TO BE PAID IS Rs");
        getContentPane().add(paid);
        paid.setBounds(530, 490, 250, 30);
        getContentPane().add(jLabel1);
        jLabel1.setBounds(510, 280, 0, 0);

        billp.setText("     ");
        getContentPane().add(billp);
        billp.setBounds(790, 450, 60, 30);

        paidp.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                paidpActionPerformed(evt);
            }
        });
        getContentPane().add(paidp);
        paidp.setBounds(790, 490, 60, 30);

        wallp.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                wallpActionPerformed(evt);
            }
        });
        getContentPane().add(wallp);
        wallp.setBounds(790, 530, 60, 30);

        jLabel2.setFont(new java.awt.Font("Tahoma", 3, 20)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("ORDER PLACED SUCCESSFULLY // YOUR ORDER DETAILS ARE GIVEN BELOW ");
        getContentPane().add(jLabel2);
        jLabel2.setBounds(50, 20, 810, 40);

        IMAGE.setBackground(new java.awt.Color(255, 204, 255));
        IMAGE.setIcon(new javax.swing.ImageIcon(getClass().getResource("/sign/ty.jpg"))); // NOI18N
        getContentPane().add(IMAGE);
        IMAGE.setBounds(0, 0, 890, 590);

        setSize(new java.awt.Dimension(910, 634));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void paidpActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_paidpActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_paidpActionPerformed

    private void wallpActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_wallpActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_wallpActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(thankyou.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(thankyou.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(thankyou.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(thankyou.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> {
            // new thankyou().setVisible(true);
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel IMAGE;
    private javax.swing.JLabel bill;
    private javax.swing.JTextField billp;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel paid;
    private javax.swing.JTextField paidp;
    private javax.swing.JLabel wall;
    private javax.swing.JTextField wallp;
    // End of variables declaration//GEN-END:variables
}
